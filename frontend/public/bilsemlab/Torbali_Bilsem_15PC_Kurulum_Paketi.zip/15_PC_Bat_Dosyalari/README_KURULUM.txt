===============================================================
   TORBALI BİLİM VE SANAT MERKEZİ (BİLSEM)
   15 BİLGİSAYAR İÇİN LABORATUVAR İZLEME VE YÖNETİM SİSTEMİ
===============================================================

Canlı Öğretmen Yönetim Paneli:
https://ogretmenlerodasi.info/bilsemlab

---------------------------------------------------------------
1. KURULUM YÖNTEMLERİ (ÇOK BASİT)
---------------------------------------------------------------
YÖNTEM A - Her Bilgisayar İçin Özel Hazırlanmış BAT (TAVSİYE EDİLEN):
  - Bu klasördeki dosyaları bir USB belleğe atın.
  - 1. Bilgisayara takıp "Bilsem_PC01_Kur.bat" dosyasına çift tıklayın.
  - 2. Bilgisayara takıp "Bilsem_PC02_Kur.bat" dosyasına çift tıklayın.
  - ...
  - 15. Bilgisayara takıp "Bilsem_PC15_Kur.bat" dosyasına çift tıklayın.
  - Hepsi bu kadar! Saniyeler içinde kurulur, arka planda sessizce
    çalışmaya başlar ve bilgisayar her açıldığında otomatik açılır.

YÖNTEM B - Tek Universal Dosya İle Kurulum (BilsemLabSetup.bat):
  - "BilsemLabSetup.bat" dosyasını çalıştırın.
  - Size bu bilgisayarın numarasını (1-15) sorar. Numarayı yazıp Enter'a basın.

---------------------------------------------------------------
2. ÖZELLİKLER & ÖĞRETMEN YÖNETİM PANELİ KONTROLLERİ:
---------------------------------------------------------------
  * 15 PC Canlı Ekran Önizleme (Ultra düşük gecikme)
  * Tek tıkla Tam Ekran Canlı İzleme ve Yakınlaştırma
  * Toplu veya Seçili Bilgisayarları Kilitleme (Dikkat Modu)
  * Öğretmen Ekranını Öğrencilere Canlı Yayınlama (Projeksiyon Modu)
  * Anlık Duyuru & Mesaj Gönderme
  * Toplu Web Sitesi Açtırma (EBA, Scratch, PythonLab vb.)
  * Masaüstü Temizliği, İndirilenleri Boşaltma, Arka Plan Değiştirme
  * MEB Güvenlik Sertifikasını Tek Tıkla Dağıtma & Yükleme
  * Toplu Bilgisayar Kapatma / Yeniden Başlatma

---------------------------------------------------------------
3. KALDIRMAK İSTERSENİZ:
---------------------------------------------------------------
  - Klasördeki "BilsemLab_Kaldir.bat" dosyasına çift tıklamanız yeterlidir.
