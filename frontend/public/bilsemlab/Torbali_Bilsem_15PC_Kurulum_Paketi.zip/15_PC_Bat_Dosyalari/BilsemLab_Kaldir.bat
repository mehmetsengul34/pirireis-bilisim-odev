@echo off
chcp 65001 >nul
title Torbalı Bilsem Laboratuvar Servisi Kaldırma

echo =======================================================
echo     TORBALI BILSEM LAB SERVISI SISTEMDEN KALDIRILIYOR
echo =======================================================
echo.

taskkill /f /im WinSystemHost.exe >nul 2>&1
taskkill /f /im WinSystemGuard.exe >nul 2>&1
taskkill /f /im BilsemLabHost.exe >nul 2>&1
taskkill /f /im PiriReisLabHost.exe >nul 2>&1

reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "WinSystemService" /f >nul 2>&1

set "STARTUP_VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\WinSystemService.vbs"
if exist "%STARTUP_VBS%" del /f /q "%STARTUP_VBS%" >nul 2>&1

set "INSTALL_DIR=%LOCALAPPDATA%\WinSystemService"
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%" >nul 2>&1

echo.
echo =======================================================
echo  [OK] Torbalı Bilsem Lab Servisi ve baslangic kayitlari
echo       sistemden tamamen temizlendi.
echo =======================================================
echo.
pause
exit /b 0
